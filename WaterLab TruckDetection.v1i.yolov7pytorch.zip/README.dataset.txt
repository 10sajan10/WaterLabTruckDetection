# WaterLab TruckDetection > 2024-04-18 8:31pm
https://universe.roboflow.com/truckdetection-13pwf/waterlab-truckdetection

Provided by a Roboflow user
License: CC BY 4.0

